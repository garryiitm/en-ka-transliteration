script Package
==============

:mod:`indic_scripts` Module
---------------------------

.. automodule:: indicnlp.script.indic_scripts
    :members:
    :undoc-members:
    :show-inheritance:

