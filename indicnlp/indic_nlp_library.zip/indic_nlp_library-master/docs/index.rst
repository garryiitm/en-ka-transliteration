.. Indic NLP Library documentation master file, created by
   sphinx-quickstart on Tue Nov  3 01:50:37 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Indic NLP Library's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 2

  indicnlp

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

