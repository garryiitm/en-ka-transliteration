transliterate Package
=====================

:mod:`itrans_transliterator` Module
-----------------------------------

.. automodule:: indicnlp.transliterate.itrans_transliterator
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`sinhala_transliterator` Module
------------------------------------

.. automodule:: indicnlp.transliterate.sinhala_transliterator
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`unicode_transliterate` Module
-----------------------------------

.. automodule:: indicnlp.transliterate.unicode_transliterate
    :members:
    :undoc-members:
    :show-inheritance:

