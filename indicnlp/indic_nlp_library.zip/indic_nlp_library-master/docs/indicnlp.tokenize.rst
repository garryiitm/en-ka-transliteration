tokenize Package
================

:mod:`indic_tokenize` Module
----------------------------

.. automodule:: indicnlp.tokenize.indic_tokenize
    :members:
    :undoc-members:
    :show-inheritance:

