Auto Generated Documentation
============================

.. automodule:: indicnlp.langinfo indicnlp.common
   :members: 
